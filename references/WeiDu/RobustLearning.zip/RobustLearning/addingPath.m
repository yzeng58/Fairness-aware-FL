clear
clc

addpath(genpath('algo'))
addpath(genpath('solver'))
addpath MinMax
addpath helper

