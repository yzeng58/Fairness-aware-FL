function [K] = polykernel(X1,X2,d)
	K = (X1*X2' + 1).^d;
